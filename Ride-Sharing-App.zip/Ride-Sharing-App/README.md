# Ride-Sharing-App
React-Native Application of Ride Sharing.


Steps to run this react-native-application.

Download this zip file.
Extract these files where you want run this Application.
Rename the folder of project to *Ride-Sharing-App*
now in that folder open cmd (command prompt) and run the following commands.

1: npm i -g create-react-native-app 
2: create-react-native-app Ride-Sharing-App 
3: npm install 
4: npm start
5: project will run on Emulator or your connected phone to test
